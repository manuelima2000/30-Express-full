const supabaseUrl = "https://gkcxjzwymdhjsitnnxiv.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdrY3hqend5bWRoanNpdG5ueGl2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQwMTIwODAsImV4cCI6MjA1OTU4ODA4MH0.URI7eotN3-iia9dxOi8mxmssHHo92VamcXg2ztVqilg";
const supabase = supabase.createClient(supabaseUrl, supabaseKey);

async function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    showMessage("Erro ao entrar: " + error.message);
  } else {
    showMessage("Login com sucesso! Redirecionando...");
    window.location.href = "index.html";
  }
}

async function register() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const { error } = await supabase.auth.signUp({ email, password });
  if (error) {
    showMessage("Erro ao registrar: " + error.message);
  } else {
    showMessage("Registrado com sucesso! Verifique seu email.");
  }
}

function showMessage(msg) {
  document.getElementById("message").textContent = msg;
}