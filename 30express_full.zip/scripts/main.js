document.addEventListener("DOMContentLoaded", () => {
  const produtosEl = document.getElementById("produtos");
  produtosEl.innerHTML = "<p>Em breve, nossos produtos aparecerão aqui!</p>";
});